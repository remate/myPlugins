import IconFont from "./icon-font.vue"

IconFont.install = function(Vue) {
  Vue.component(IconFont.name, IconFont)
}

export default IconFont
