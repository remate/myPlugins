import LayoutHeader from "./layout-header.vue"

LayoutHeader.install = function(Vue) {
  Vue.component(LayoutHeader.name, LayoutHeader)
}

export default LayoutHeader
