import IconTooltip from "./icon-tooltip.vue"

IconTooltip.install = function(Vue) {
  Vue.component(IconTooltip.name, IconTooltip)
}

export default IconTooltip
