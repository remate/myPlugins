import PageIntroduce from "./page-introduce.vue"

PageIntroduce.install = function(Vue) {
  Vue.component(PageIntroduce.name, PageIntroduce)
}

export default PageIntroduce
