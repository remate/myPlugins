import TextHiddenTooltip from "./text-hidden-tooltip.vue"

TextHiddenTooltip.install = function(Vue) {
  Vue.component(TextHiddenTooltip.name, TextHiddenTooltip)
}

export default TextHiddenTooltip
