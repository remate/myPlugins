import LayoutSidebar from "./layout-sidebar.vue"

LayoutSidebar.install = function(Vue) {
  Vue.component(LayoutSidebar.name, LayoutSidebar)
}

export default LayoutSidebar
