import IconButton from "./icon-button.vue"

IconButton.install = function(Vue) {
  Vue.component(IconButton.name, IconButton)
}

export default IconButton
