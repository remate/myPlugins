---
name: 'Bug report 🐞'
about: "If something isn't working as expected 🤔."
---

# Bug report 🐞

## Version & Environment

## Expectation

## Actual results (or Errors)
