## API

### Props

| Prop | Description | Type | Default | 
|-----------------|---------| --- | -- |
| `error-message` | Error message | _string_ | `-` |
| `extra-message` | Extra message | _string_ | `-` |