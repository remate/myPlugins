export default {
  functionCall: 'Function Call',
  basicUsage: 'Basic Usage',
  modifyTitle: 'Modify Title',
  componentCall: 'Component Call',
  yourSelected: 'Your selected is:',
  customTitle: 'Choose whichever you like',
  disableCloseOnClickAction: 'Disable close on click action',
  disabled: 'Action Disabled',
  customActionStyles: 'Custom Action Styles',
}
