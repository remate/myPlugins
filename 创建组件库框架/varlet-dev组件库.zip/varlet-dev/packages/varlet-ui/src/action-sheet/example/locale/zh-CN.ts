export default {
  functionCall: '函数调用',
  basicUsage: '基本使用',
  modifyTitle: '修改标题',
  componentCall: '组件调用',
  yourSelected: '您选择的是:',
  customTitle: '选择一个你喜欢的吧',
  disableCloseOnClickAction: '禁用点击选项时关闭动作面板',
  disabled: '禁用选项',
  customActionStyles: '自定义选项样式',
}
