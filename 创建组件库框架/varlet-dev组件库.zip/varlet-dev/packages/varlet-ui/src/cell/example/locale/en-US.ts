export default {
  basicUsage: 'Basic Usage',
  showIcon: 'Show Icon',
  showDesc: 'Show Description',
  showBorder: 'Show Border',
  content: 'This is Cell',
  description: 'Description',
  list: 'Use As List Item',
}
