export default {
  basicUsage: 'Basic Usage',
  dashed: 'Dashed Divider',
  inset: 'Inset Divider',
  vertical: 'Vertical Divider',
  text: 'Text',
  withDesc: 'Description Text',
  withDescText: 'Description',
  custom: 'Custom Description',
  hairline: 'Use 0.5px Divider',
}
