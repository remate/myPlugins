export default {
  basicUsage: 'Basic Usage',
  customStyle: 'Custom Background Color',
  addSlotsAtTitle: 'Add Slots At Title',
  title: 'Title',
  addLeftAndRightSlot: 'Add Left And Right Slot',
  option: 'OPTION',
  search: 'search',
  round: 'Use Border Radius',
  custom: 'Custom Content',
}
