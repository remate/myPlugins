export default {
  basicUsage: '基本使用',
  customStyle: '自定义背景色',
  addSlotsAtTitle: '添加标题处插槽',
  title: '标题',
  addLeftAndRightSlot: '添加左右插槽',
  option: '选项卡',
  search: '搜索',
  round: '开启圆角',
  custom: '扩展内容',
}
