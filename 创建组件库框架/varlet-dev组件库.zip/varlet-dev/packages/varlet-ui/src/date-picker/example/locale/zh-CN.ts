export default {
  basicUsage: '基本使用',
  monthPicker: '月份选择器',
  multiple: '多选',
  range: '选择范围',
  dateLimit: '日期限制',
  custom: '自定义',
  year: '年',
  month: '月',
  divider: '年',
}
