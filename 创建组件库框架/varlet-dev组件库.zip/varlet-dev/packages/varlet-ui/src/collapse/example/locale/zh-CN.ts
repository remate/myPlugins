export default {
  basicUsage: '基本使用',
  hideMargin: '隐藏边距',
  accordionMode: '手风琴模式',
  disabled: '禁用',
  enable: '启用',
  customContent: '自定义内容',
  title: '标题',
  text: '文本',
  slotTitle: '这是标题',
  slotContent: '这是内容',
}
