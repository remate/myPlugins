export default {
  basicUsage: 'Basic Usage',
  hideMargin: 'Hide Margin',
  accordionMode: 'Accordion Mode',
  disabled: 'Disabled',
  enable: 'Enable',
  customContent: 'Custom Content',
  title: 'Title',
  text: 'Hello World',
  slotTitle: 'This is a Title',
  slotContent: 'This is a content',
}
