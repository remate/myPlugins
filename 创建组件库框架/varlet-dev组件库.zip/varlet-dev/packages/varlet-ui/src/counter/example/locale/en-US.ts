export default {
  basicUsage: 'Basic Usage',
  range: 'Set the value range',
  step: 'Set step',
  toFixed: 'Decimal length',
  disabled: 'Disabled',
  readonly: 'Readonly',
  lazyChange: 'Asynchronous change',
  size: 'Set size',
  validate: 'Validate',
  validateMessage: 'Please select a value greater than 5',
}
