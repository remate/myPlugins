import { Validation } from '../form/provide'

export type CounterProvider = Validation
