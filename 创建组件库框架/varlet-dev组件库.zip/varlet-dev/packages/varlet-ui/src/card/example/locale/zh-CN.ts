export default {
  basicUsage: '基本使用',
  title: '本草纲目',
  showSubtitle: '显示副标题',
  outline: '外边框',
  subtitle: '我表情悠哉 跳个大概',
  horizontal: '横向显示',
  description:
    '如果华佗再世,崇洋都被医治,外邦来学汉字,激发我民族意识。马钱子、决明子、苍耳子，还有莲子；黄药子、苦豆子、川楝子，我要面子。用我的方式，改写一部历史。没什么别的事，跟着我念几个字。山药当归枸杞 GO，山药 当归 枸杞 GO，看我抓一把中药，服下一帖骄傲~',
  showImage: '显示图片',
  useSlot: '使用插槽',
  action1: '操作 1',
  action2: '操作 2',
  showRipple: '水波效果',
  floating: '漂浮',
}
