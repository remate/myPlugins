export default {
  basicUsage: 'Basic Usage',
  separator: 'Separator',
  childSeparator: 'Child Separator',
  separatorSlot: 'Separator Slot',
  level1: 'Home',
  level2: 'Link 1',
  level3: 'Link 2',
  events: 'Events',
}
