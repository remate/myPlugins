export default {
  basicUsage: '基本用法',
  separator: '分隔符',
  childSeparator: '子级分隔符',
  separatorSlot: '分隔符插槽',
  level1: '首页',
  level2: '一级',
  level3: '二级',
  events: '注册事件',
}
