export default {
  basicUsage: 'Basic Usage',
  customFormat: 'Custom Format',
  showMillisecond: 'Show Millisecond',
  customStyle: 'Custom Style',
  manualControl: 'Manual Control',
  format: 'DD Day, HH:mm:ss',
  startText: 'Start',
  pauseText: 'Pause',
  resetText: 'Reset',
}
