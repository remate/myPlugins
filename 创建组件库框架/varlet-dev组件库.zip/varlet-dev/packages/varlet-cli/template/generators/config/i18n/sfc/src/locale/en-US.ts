import { Pack } from './index'

// for component's internal
export default {
  // Button component
  button: 'Button',
} as Pack
