import type { Pack } from '../../types'

declare const enUS: Pack

export default enUS
