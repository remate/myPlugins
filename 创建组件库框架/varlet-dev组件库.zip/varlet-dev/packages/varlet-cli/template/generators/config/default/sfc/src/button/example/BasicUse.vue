<script setup>
import VarButton from '..'
</script>

<template>
  <var-button>起步</var-button>
</template>
