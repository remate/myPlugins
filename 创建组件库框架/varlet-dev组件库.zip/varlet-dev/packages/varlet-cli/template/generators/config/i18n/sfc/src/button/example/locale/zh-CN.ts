export default {
  basicUse: '基本使用',
  modifyColor: '修改颜色',
  start: '起步',
}
