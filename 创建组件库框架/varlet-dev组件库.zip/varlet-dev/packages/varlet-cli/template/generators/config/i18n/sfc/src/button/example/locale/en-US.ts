export default {
  basicUse: 'Basic use',
  modifyColor: 'Modify Color',
  start: 'Start',
}
