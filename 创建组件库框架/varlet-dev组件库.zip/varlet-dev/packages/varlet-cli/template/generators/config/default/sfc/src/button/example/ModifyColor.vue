<script setup>
import VarButton from '..'
</script>

<template>
  <var-button color="#03A9F4">起步</var-button>
</template>
