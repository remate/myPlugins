import type { App } from 'vue'

export const install: (app: App) => void

export * from './basicComponent'
export * from './button'
export * from './locale'
