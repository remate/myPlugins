<template>
  <div>
    <press-row>
      <el-card shadow="always"> 总是显示 </el-card>
      <el-card shadow="hover" style="margin: 0 10px;"> 鼠标悬浮时显示 </el-card>
      <el-card shadow="never"> 从不显示 </el-card>
    </press-row>
  </div>
</template>


